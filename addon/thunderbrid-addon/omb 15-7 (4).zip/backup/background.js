/**
 * OpenMailBot — Thunderbird Add-on
 * background.js — Full-feature background service worker
 *
 * Feature parity with gmail_summariser.gs:
 *  • Summarize thread (full thread, not just current message)
 *  • Chat with thread (RAG)
 *  • Draft with attachments (pipeline API + job polling)
 *  • Create draft response from summary
 *  • Settings management (local + backend sync / reset / fetch)
 *  • Historical bulk email indexing (batch, cancellable, status tracking)
 *  • Domain / email privacy filters
 *  • Bulk-job progress & cancellation UI
 */

"use strict";

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS & DEFAULTS
// ─────────────────────────────────────────────────────────────────────────────

const DEFAULT_FLASK_URL  = "http://m15.lsdiedb39c.pagekite.me/";
let   ALLOWED_EXTENSIONS = [".pdf", ".csv", ".pptx", ".ppt", ".xlsx", ".xls", ".docx", ".doc"];

// ─── BACKGROUND EMAIL MONITOR CONSTANTS ──────────────────────────────────────
const MONITOR_ALARM_NAME     = "openmailbot-monitor";
const MONITOR_INTERVAL_MINS  = 1;       // check every minute (mirrors GAS CONFIG.CHECK_INTERVAL_MINUTES)
const MONITOR_LAST_CHECK_KEY = "monitor_last_check_time";
const MONITOR_PROCESSED_KEY  = "monitor_processed_ids";
const MONITOR_MAX_IDS        = 1000;    // ring-buffer cap for processed-IDs list

// ─── THUNDERBIRD LABEL COLORS (mirrors backend _GMAIL_LABEL_COLORS) ───────────
// Key  = lowercase label name (used as Thunderbird tag key)
// Value = hex background color
const THUNDERBIRD_LABEL_COLORS = {
  "response"      : "#4A86E8",
  "fyi"           : "#16A766",
  "notification"  : "#B7B7B7",
  "meeting"       : "#9900FF",
  "awaiting reply": "#FFFF00",
  "awaiting_reply": "#FFFF00",
  "escalation"    : "#CC0000",
  "hotels"        : "#FF9900",
  "airline"       : "#7F6000",
  "airlines"      : "#7F6000",
  "travel"        : "#274E13",
  "restaurant"    : "#FF9900",
  "booking"       : "#4A86E8",
  "bank"          : "#16A766",
  "recruitment"   : "#274E13"
};

// ─── LABEL MAPPING SYSTEM (Backend Labels → Thunderbird Tags) ─────────────────
// Hard-coded mapping replaces fuzzy similarity matching for predictable label assignment

let _labelMappingInitialized = false;

/**
 * Initialize label mapping (LEGACY - using hard-coded mapping instead)
 * Previously did similarity matching; now just logs available tags for reference.
 */
async function _initializeLabelMapping() {
  if (_labelMappingInitialized) return;
  
  try {
    const existingTags = await browser.messages.tags.list();
    console.log(`[OpenMailBot][LabelMapping] Available Thunderbird tags (${existingTags.length}):`);
    existingTags.forEach(tag => {
      console.log(`  • ${tag.key}: ${tag.tag} (color: ${tag.color})`);
    });
    console.log(`[OpenMailBot][LabelMapping] Using HARD-CODED mapping (see HARD_CODED_LABEL_MAPPING constant)`);
    _labelMappingInitialized = true;
  } catch (e) {
    console.error(`[OpenMailBot][LabelMapping] ❌ Failed to list tags: ${e.message}`);
  }
}

/**
 * HARD-CODED LABEL MAPPING: Backend Labels → Thunderbird Tag Keys
 * This mapping defines the exact transformation of backend labels to predefined Thunderbird tags.
 * 
 * Mapping Chart:
 * ────────────────────────────────────────────────────────────────
 * Backend Label   │ Thunderbird Key │ Thunderbird Tag Name
 * ────────────────────────────────────────────────────────────────
 * response        │ fyi             │ FYI
 * FYI             │ fyi             │ FYI
 * Notification    │ notification    │ Notification
 * meeting         │ meeting         │ Meeting
 * Escalation      │ escalation      │ Escalation
 * hotels          │ $label2         │ Work
 * airlines        │ $label2         │ Work
 * travel          │ $label2         │ Work
 * restaurant      │ $label5         │ Later
 * booking         │ $label5         │ Later
 * bank            │ label1          │ Bank
 * Insurance       │ $label1         │ Important
 * Other           │ $label4         │ To Do
 * ────────────────────────────────────────────────────────────────
 */
const HARD_CODED_LABEL_MAPPING = {
  "response": "fyi",
  "fyi": "fyi",
  "notification": "notification",
  "meeting": "meeting",
  "escalation": "escalation",
  "hotels": "$label2",
  "airlines": "$label2",
  "travel": "$label2",
  "restaurant": "$label5",
  "booking": "$label5",
  "bank": "label1",
  "insurance": "$label1",
  "other": "$label4"
};

/**
 * Map a backend label to an existing Thunderbird tag key using HARD-CODED mapping.
 * Returns the exact tag key from the mapping; no fuzzy matching.
 */
function _mapBackendLabelToThunderbirdKey(backendLabel) {
  if (!backendLabel) return null;
  
  // Normalize the backend label for lookup (lowercase)
  const normalizedLabel = String(backendLabel).toLowerCase().trim();
  
  // Check hard-coded mapping
  if (HARD_CODED_LABEL_MAPPING[normalizedLabel]) {
    const mappedKey = HARD_CODED_LABEL_MAPPING[normalizedLabel];
    console.log(`[OpenMailBot][LabelMapping] ✅ HARD-CODED: "${backendLabel}" → "${mappedKey}"`);
    return mappedKey;
  }
  
  // Not in mapping — use backend label as-is (will be created as new tag)
  console.log(`[OpenMailBot][LabelMapping] ⚠️  Not in mapping: "${backendLabel}" — will use as tag key`);
  return backendLabel;
}

// ─── ADDON CONFIG (addon_config.json — addon-side only, never sent to server) ─

let _addonConfig = null;

/**
 * Load the bundled addon_config.json file once and cache it.
 * This is the addon-side equivalent of .env / app secrets.
 */
async function getAddonConfig() {
  if (_addonConfig) return _addonConfig;
  try {
    const url  = browser.runtime.getURL("addon_config.json");
    const resp = await fetch(url);
    if (!resp.ok) throw new Error("HTTP " + resp.status);
    _addonConfig = await resp.json();
    // Update allowed attachment extensions from config
    if (Array.isArray(_addonConfig.allowed_attachment_extensions)) {
      ALLOWED_EXTENSIONS = _addonConfig.allowed_attachment_extensions;
    }
    console.log("[OpenMailBot] addon_config.json loaded", _addonConfig);
  } catch (e) {
    console.warn("[OpenMailBot] Could not load addon_config.json, using defaults:", e.message);
    _addonConfig = {
      domain_filters: { blocked_domains: [], blocked_addresses: [] },
      bulk_processing: { default_months: 3, batch_size: 10, max_messages_per_run: 2000, request_delay_ms: 200 },
      allowed_attachment_extensions: ALLOWED_EXTENSIONS
    };
  }
  return _addonConfig;
}

/**
 * Get the merged domain filter list:
 *   stored user filters (browser.storage.local)  UNION  config-file defaults
 * This ensures config-file blocked domains always apply even if storage is cleared.
 */
async function _getMergedDomainFilters() {
  const [storedR, cfg] = await Promise.all([
    browser.storage.local.get("domain_filters"),
    getAddonConfig()
  ]);
  const stored  = storedR.domain_filters || [];
  const cfgDoms = (cfg.domain_filters && cfg.domain_filters.blocked_domains)  || [];
  const cfgAddr = (cfg.domain_filters && cfg.domain_filters.blocked_addresses) || [];
  const merged  = [...new Set([...stored, ...cfgDoms, ...cfgAddr])];
  return merged;
}

const DEFAULT_SETTINGS = {
  backend_url        : DEFAULT_FLASK_URL,
  mode               : "inbuilt",
  llm_provider       : "inbuilt",
  llm_api_key        : "",
  llm_model          : "gpt-4o-mini",
  llm_base_url       : "",
  embedding_provider : "inbuilt",
  embedding_api_key  : "",
  embedding_model    : "text-embedding-3-small",
  vector_provider    : "inbuilt",
  vector_url         : "",
  vector_api_key     : "",
  user_name          : "",
  user_position      : "",
  user_tone          : "professional",
  system_prompt      : ""
};

/* keep a reference so other functions below can use DEFAULT_FLASK_SERVER_URL */
const DEFAULT_FLASK_SERVER_URL = DEFAULT_FLASK_URL;

// ─── SETTINGS HELPERS ──────────────────────────────────────────────────────────

async function _getSettings() {
  const r = await browser.storage.local.get("user_settings");
  return Object.assign({}, DEFAULT_SETTINGS, r.user_settings || {});
}

async function getBackendUrl() {
  try {
    // addon_config.json backend_url is authoritative — always prefer it over stored settings
    const [s, cfg] = await Promise.all([_getSettings(), getAddonConfig()]);
    const url = (cfg.backend_url || s.backend_url || DEFAULT_FLASK_URL).replace(/\/$/,"");
    return url;
  } catch (e) {
    return DEFAULT_FLASK_URL;
  }
}

// ─── SETTINGS HANDLERS ─────────────────────────────────────────────────────────

async function handleLoadSettings() {
  return { success: true, settings: await _getSettings() };
}

async function handleSaveSettings({ settings }) {
  const merged = Object.assign({}, DEFAULT_SETTINGS, settings);
  await browser.storage.local.set({ user_settings: merged });
  try { await _syncSettingsToBackend(merged); } catch (e) { console.warn("Sync failed:", e.message); }
  return { success: true, settings: merged };
}

async function handleResetSettings() {
  await browser.storage.local.set({ user_settings: DEFAULT_SETTINGS });
  return { success: true, settings: DEFAULT_SETTINGS };
}

async function handleSyncSettings(data) {
  const settings = (data && data.settings) ? data.settings : await _getSettings();
  await _syncSettingsToBackend(settings);
  return { success: true };
}

async function _syncSettingsToBackend(settings) {
  const base   = (settings.backend_url || DEFAULT_FLASK_URL).replace(/\/$/,"");
  const userId = await getUserId();
  const resp   = await fetch(`${base}/api/settings`, {
    method : "POST",
    headers: { "Content-Type": "application/json" },
    body   : JSON.stringify({ user_id: userId, settings })
  });
  if (!resp.ok) throw new Error(`Backend ${resp.status}: ${await resp.text()}`);
  return resp.json();
}

// ─── DOMAIN FILTER HANDLERS ───────────────────────────────────────────────────────

/**
 * Returns both user-saved filters AND the config-file defaults (merged, deduplicated).
 * The UI always shows the merged list so users know what's actually active.
 */
async function handleGetDomainFilters() {
  const filters = await _getMergedDomainFilters();
  return { success: true, filters };
}

async function handleSaveDomainFilters({ filters }) {
  // Save only the user-defined filters; config-file defaults are always merged at read time
  const unique = [...new Set((filters||[]).map(f=>f.toLowerCase().trim()).filter(Boolean))];
  await browser.storage.local.set({ domain_filters: unique });
  return { success: true, filters: unique };
}

async function handleTestDomainFilters() {
  try {
    const filters = await _getMergedDomainFilters();
    if (!filters.length) return { success:true, filterCount:0, filtered:0, allowed:0, examples:[], noFilters:true };
    const accounts = await browser.accounts.list();
    if (!accounts.length) return { success:true, filterCount:filters.length, filtered:0, allowed:0, examples:[] };
    const inbox = _findInboxFolder(accounts[0].folders);
    if (!inbox) return { success:true, filterCount:filters.length, filtered:0, allowed:0, examples:[] };
    const page = await browser.messages.list(inbox);
    const msgs = (page.messages||[]).slice(0,20);
    let filtered=0; let allowed=0; const examples=[];
    for (const msg of msgs) {
      const block = _shouldFilterEmail(msg.author,filters)||(msg.recipients||[]).some(r=>_shouldFilterEmail(r,filters));
      if (block) { filtered++; if(examples.length<5) examples.push(`🚫 ${(msg.subject||"").substring(0,50)} (From: ${msg.author})`); }
      else allowed++;
    }
    return { success:true, filterCount:filters.length, filtered, allowed, examples, threadsScanned:msgs.length };
  } catch(e) { throw new Error("Filter test: "+e.message); }
}

function _findInboxFolder(folders) {
  if (!folders) return null;
  for (const f of folders) {
    if (f.type==="inbox") return f;
    const sub = _findInboxFolder(f.subFolders);
    if (sub) return sub;
  }
  return null;
}

function _shouldFilterEmail(address, filters) {
  if (!address||!filters||!filters.length) return false;
  const raw  = address.toLowerCase().trim();
  const m    = raw.match(/<(.+?)>/);
  const addr = m ? m[1] : raw;
  for (const f of filters) {
    const fl = f.toLowerCase().trim();
    if (!fl) continue;
    if (fl.includes("@")) { if (addr===fl) return true; }
    else { const d=addr.split("@")[1]; if(d&&d===fl) return true; }
  }
  return false;
}

// ─── BULK PROCESSING ─────────────────────────────────────────────────────────────────

async function handleSaveProcessMonths({ months }) {
  await browser.storage.local.set({ process_last_n_months: months||"3" });
  return { success: true };
}

async function handleGetProcessMonths() {
  const r = await browser.storage.local.get("process_last_n_months");
  return { success: true, months: r.process_last_n_months||"3" };
}

async function handleGetBulkJobStatus() {
  const r = await browser.storage.local.get(["bulk_job_state","bulk_job_abort"]);
  return { success: true, state: r.bulk_job_state||null, aborted: r.bulk_job_abort===true };
}

async function handleCancelBulkJob() {
  await browser.storage.local.set({ bulk_job_abort: true });
  return { success: true };
}

async function handleRunBulkProcess({ months }) {
  console.log("\n\n");
  console.log("🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴");
  console.log("🔴 BULK INDEX EMAIL BUTTON CLICKED!");
  console.log("🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴\n");
  
  const cfg = await getAddonConfig();
  const n      = parseInt(months || String((cfg.bulk_processing && cfg.bulk_processing.default_months) || 3), 10);
  const before = new Date();
  const after  = new Date();
  after.setMonth(after.getMonth() - n);
  
  console.log(`[OpenMailBot][BulkStart] Processing last ${n} months`);
  console.log(`[OpenMailBot][BulkStart] Date range: ${after.toLocaleDateString()} → ${before.toLocaleDateString()}`);
  console.log(`[OpenMailBot][BulkStart] Backend URL: ${await getBackendUrl()}`);
  console.log(`[OpenMailBot][BulkStart] User ID: ${await getUserId()}`);
  console.log(`[OpenMailBot][BulkStart] Config: ${JSON.stringify(cfg, null, 2)}\n`);
  
  const state = {
    n, months: String(n),
    afterStr : after.toLocaleDateString(),
    beforeStr: before.toLocaleDateString(),
    status   : "running",
    offset   : 0,
    stats    : { threadsScanned:0, messagesFound:0, labeled:0, skipped:0, filtered:0, errors:0 }
  };
  await browser.storage.local.set({ bulk_job_state: state, bulk_job_abort: false });
  _runBulkAsync(n, after, before, state).catch(e => {
    console.error("\n[OpenMailBot] 274c BULK PROCESS ERROR:", e.message);
    console.error("[OpenMailBot] Stack:", e.stack);
    browser.storage.local.set({ bulk_job_state: Object.assign({}, state, { status:"error", error:e.message }) });
  });
  return { success: true, state };
}

async function _runBulkAsync(n, after, before, state) {
  const cfg        = await getAddonConfig();
  const bp         = cfg.bulk_processing || {};
  const BATCH      = bp.batch_size           || 10;
  const MAX_MSGS   = bp.max_messages_per_run || 2000;
  const DELAY_MS   = bp.request_delay_ms     || 200;

  const userId     = await getUserId();
  const backendUrl = await getBackendUrl();
  const filters    = await _getMergedDomainFilters();   // addon-side filter list (storage + config)

  console.log(`[OpenMailBot][BulkIndex] ▶ Starting bulk index | user=${userId} | backendUrl=${backendUrl} | months=${n} | dateRange=${after.toLocaleDateString()} → ${before.toLocaleDateString()} | BATCH=${BATCH} | MAX_MSGS=${MAX_MSGS} | domainFilters=${filters.length}`);

  let totalProcessed = 0;

  const accounts = await browser.accounts.list();
  console.log(`[OpenMailBot][BulkIndex] Found ${accounts.length} mail account(s)`);
  
  for (const acc of accounts) {
    if (totalProcessed >= MAX_MSGS) break;

    console.log(`[OpenMailBot][BulkIndex] Processing account: ${acc.name||acc.id}`);
    
    // Search ALL folders, not just inbox, to catch Sent/other folders
    const allFolders = _collectAllFolders(acc.folders);
    console.log(`[OpenMailBot][BulkIndex] Found ${allFolders.length} folder(s) to scan`);
    
    for (const folder of allFolders) {
      if (totalProcessed >= MAX_MSGS) break;

      console.log(`[OpenMailBot][BulkIndex] 📂 Scanning folder: "${folder.name}" (type=${folder.type||"unknown"})`);

      let page;
      try {
        page = await browser.messages.list(folder);
      } catch(e) {
        console.warn("[OpenMailBot] Cannot list folder:", folder.name, e.message);
        continue;
      }

      while (page) {
        // Abort check
        const ac = await browser.storage.local.get("bulk_job_abort");
        if (ac.bulk_job_abort) {
          console.log(`[OpenMailBot][BulkIndex] 🛑 Abort detected`);
          await browser.storage.local.set({ bulk_job_state: Object.assign({}, state, { status:"cancelled" }) });
          return;
        }

        const rawMsgs = page.messages || [];
        console.log(`[OpenMailBot][BulkIndex] Page has ${rawMsgs.length} message(s)`);
        state.stats.threadsScanned += rawMsgs.length;

        // Filter by date and domain
        const msgs = rawMsgs.filter(m => {
          const d = m.date ? new Date(m.date) : null;
          if (!d || isNaN(d.getTime())) return false;   // skip messages with no/invalid date
          if (d < after || d > before)  return false;   // outside date window
          if (_shouldFilterEmail(m.author, filters))    { state.stats.filtered++; return false; }
          if ((m.recipients||[]).some(r => _shouldFilterEmail(r, filters))) { state.stats.filtered++; return false; }
          return true;
        });

        console.log(`[OpenMailBot][BulkIndex] After filtering: ${msgs.length} message(s) to process`);
        state.stats.messagesFound += msgs.length;

        // Process in batches
        for (let i = 0; i < msgs.length; i += BATCH) {
          if (totalProcessed >= MAX_MSGS) break;

          const ac2 = await browser.storage.local.get("bulk_job_abort");
          if (ac2.bulk_job_abort) {
            console.log(`[OpenMailBot][BulkIndex] 🛑 Abort detected in batch loop`);
            await browser.storage.local.set({ bulk_job_state: Object.assign({}, state, { status:"cancelled" }) });
            return;
          }

          console.log(`[OpenMailBot][BulkIndex] Processing batch ${Math.floor(i/BATCH)+1} (${Math.min(BATCH, msgs.length-i)} messages)`);

          for (const msg of msgs.slice(i, i + BATCH)) {
            if (totalProcessed >= MAX_MSGS) break;
            try {
              const full = await browser.messages.getFull(msg.id);
              const tid  = msg.headerMessageId || String(msg.id);
              // Store attachments FIRST so label-email's CheckAndStoreAttachmentsPipeline can find them on disk
              const atts = await _getAttachments(msg.id);
              if (atts.length) {
                const storeAttsUrl = `${backendUrl}/api/store-attachments`;
                console.log(`[OpenMailBot][BulkIndex] POST ${storeAttsUrl} | thread_id=${tid} | msg_id=${msg.id} | attachments=${atts.length} [${atts.map(a=>a.filename).join(", ")}]`);
                await _storeAtts(backendUrl, userId, tid, String(msg.id), atts);
                console.log(`[OpenMailBot][BulkIndex] ✓ store-attachments OK | thread_id=${tid}`);
              }
              // Call /api/label-email (full pipeline: preprocess → vector embed → label → graph store)
              // This is the correct endpoint — /api/log-email only dumps JSON to disk with no indexing
              const labelEmailUrl = `${backendUrl}/api/label-email`;
              const msgData = _fmtMsg(msg, full);
              console.log(`[OpenMailBot][BulkIndex] ╔════════════════════════════════════════`);
              console.log(`[OpenMailBot][BulkIndex] ║ CALLING: POST ${labelEmailUrl}`);
              console.log(`[OpenMailBot][BulkIndex] ║ thread_id: ${tid}`);
              console.log(`[OpenMailBot][BulkIndex] ║ msg_id: ${msg.id}`);
              console.log(`[OpenMailBot][BulkIndex] ║ subject: "${msg.subject}"`);
              console.log(`[OpenMailBot][BulkIndex] ║ from: "${msg.author}"`);
              console.log(`[OpenMailBot][BulkIndex] ║ payload: ${JSON.stringify({ user_id:userId, thread_id:tid, messages: [msgData] }, null, 2)}`);
              console.log(`[OpenMailBot][BulkIndex] ╚════════════════════════════════════════`);
              const labelResult = await _labelEmailOnServer(backendUrl, userId, tid, [msgData]);
              const assignedLabel = labelResult && (labelResult.label || labelResult.category);
              console.log(`[OpenMailBot][BulkIndex] ✓ label-email OK | thread_id=${tid} | label=${assignedLabel||"(none)"}`);

              // ── Apply the label as a Thunderbird tag on the actual message ──
              if (assignedLabel) {
                await _applyThunderbirdTag(msg.id, assignedLabel);
              }

              state.stats.labeled++;
              totalProcessed++;
            } catch(e) {
              console.error(`[OpenMailBot][BulkIndex] ✗ Error processing msg_id=${msg.id} subject="${msg.subject}":`, e.message);
              state.stats.errors++;
              totalProcessed++;
            }
            // Brief delay between requests to avoid overwhelming the server
            await new Promise(r => setTimeout(r, DELAY_MS));
          }

          state.offset = state.stats.labeled + state.stats.errors;
          await browser.storage.local.set({ bulk_job_state: state });
        }

        if (page.id) {
          try { page = await browser.messages.continueList(page.id); }
          catch(e) { console.warn("[OpenMailBot] continueList:", e.message); break; }
        } else {
          break;
        }
      }
    }
  }

  const finalStatus = totalProcessed >= MAX_MSGS ? "done_limit" : "done";
  console.log(`[OpenMailBot][BulkIndex] ■ Finished | status=${finalStatus} | totalProcessed=${totalProcessed} | labeled=${state.stats.labeled} | errors=${state.stats.errors} | filtered=${state.stats.filtered}`);
  await browser.storage.local.set({ bulk_job_state: Object.assign({}, state, { status: finalStatus }) });
}

// ─── THUNDERBIRD TAG APPLICATION ─────────────────────────────────────────────

/**
 * Apply a backend label (from /api/label-email) as a Thunderbird tag on a message.
 * 
 * WORKFLOW:
 * 1. Initialize label mapping (if needed) — maps backend labels to existing Thunderbird tags
 * 2. Apply semantic mapping to find best matching tag
 * 3. Create tag if it doesn't exist
 * 4. Apply tag to message using multiple fallback methods
 *
 * KEY FIXES:
 * 1. Use browser.* consistently (not messenger.* which is unreliable in MV2)
 * 2. Thunderbird tag keys must be lowercase, no spaces (use underscores)
 * 3. tags.create() in TB 121+ takes (key, color, label) or (key, label, color) depending on version
 * 4. Wrap each step independently so one failure doesn't kill the other
 * 5. Add detailed logging at every step to pinpoint failures
 *
 * @param {number} messageId  - Thunderbird internal message id
 * @param {string} labelName  - Raw label string returned by /api/label-email (backend label)
 */
async function _applyThunderbirdTag(messageId, labelName) {
  if (!labelName) return;

  // ── Step 0: Initialize label mapping if needed ────────────────────────────
  if (!_labelMappingInitialized) {
    console.log(`[OpenMailBot][Tag] Label mapping not initialized, initializing now...`);
    await _initializeLabelMapping();
  }

  // ── Step 1: Map backend label to Thunderbird tag key ──────────────────────
  const mappedKey = _mapBackendLabelToThunderbirdKey(labelName);
  // Sanitize the key: lowercase, replace spaces with underscores, remove special chars
  const key     = (mappedKey || labelName).toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "");
  const display = labelName.charAt(0).toUpperCase() + labelName.slice(1).toLowerCase();
  const color   = (
    THUNDERBIRD_LABEL_COLORS[labelName.toLowerCase()] ||
    THUNDERBIRD_LABEL_COLORS[key] ||
    THUNDERBIRD_LABEL_COLORS[mappedKey] ||
    "#888888"
  ).toUpperCase();

  console.log(`[OpenMailBot][Tag] ▶ Applying tag | msgId=${messageId} | backendLabel="${labelName}" | mappedKey="${mappedKey}" | finalKey="${key}" | color=${color}`);

  // ── Step 2: Ensure tag exists ─────────────────────────────────────────────
  try {
    const existingTags = await browser.messages.tags.list();
    const tagExists = existingTags.some(t => (t.key || "").toLowerCase() === key);
    if (!tagExists) {
      // TB 128+: create(key, color, label) | TB 121-127: create(key, label, color)
      try {
        await browser.messages.tags.create(key, color, display);
        console.log(`[OpenMailBot][Tag] ✅ Created tag (key,color,label): "${key}"`);
      } catch (e1) {
        console.warn(`[OpenMailBot][Tag] create(key,color,label) failed: ${e1.message} — trying (key,label,color)`);
        await browser.messages.tags.create(key, display, color);
        console.log(`[OpenMailBot][Tag] ✅ Created tag (key,label,color): "${key}"`);
      }
    } else {
      console.log(`[OpenMailBot][Tag] Tag "${key}" already exists`);
    }
  } catch (e) {
    console.error(`[OpenMailBot][Tag] ❌ tags.create/list failed: ${e.message}`);
    // Continue anyway — tag may already exist even if list() failed
  }

  // ── Step 3: Apply tag to message ──────────────────────────────────────────
  // Thunderbird messages.update({ tags }) REPLACES tags, so we must merge first.
  // The tags array must contain the exact key strings (e.g. "notification", "$label1").

  // METHOD A: browser.messages.update with merged tags array
  try {
    const msgMeta     = await browser.messages.get(messageId);
    const currentTags = Array.isArray(msgMeta.tags) ? msgMeta.tags : [];
    console.log(`[OpenMailBot][Tag] Current tags on msg ${messageId}: ${JSON.stringify(currentTags)}`);

    if (currentTags.includes(key)) {
      console.log(`[OpenMailBot][Tag] ✅ Tag "${key}" already on message — nothing to do`);
      return;
    }

    const updatedTags = [...currentTags, key];
    console.log(`[OpenMailBot][Tag] Calling browser.messages.update(${messageId}, { tags: ${JSON.stringify(updatedTags)} })`);
    await browser.messages.update(messageId, { tags: updatedTags });

    // Verify it actually stuck
    const verify = await browser.messages.get(messageId);
    const verifyTags = Array.isArray(verify.tags) ? verify.tags : [];
    console.log(`[OpenMailBot][Tag] Post-update tags: ${JSON.stringify(verifyTags)}`);

    if (verifyTags.includes(key)) {
      console.log(`[OpenMailBot][Tag] ✅ Tag "${key}" successfully applied to msg ${messageId}`);
      return;
    } else {
      console.warn(`[OpenMailBot][Tag] ⚠️ update() returned no error but tag not found in verify — trying Method B`);
    }
  } catch (e) {
    console.warn(`[OpenMailBot][Tag] Method A (browser.messages.update) failed: ${e.message} — trying Method B`);
  }

  // METHOD B: messenger.messages.update (some TB versions require this namespace)
  try {
    const msgMeta     = await messenger.messages.get(messageId);
    const currentTags = Array.isArray(msgMeta.tags) ? msgMeta.tags : [];
    const updatedTags = currentTags.includes(key) ? currentTags : [...currentTags, key];

    console.log(`[OpenMailBot][Tag] Method B: messenger.messages.update(${messageId}, { tags: ${JSON.stringify(updatedTags)} })`);
    await messenger.messages.update(messageId, { tags: updatedTags });

    const verify = await messenger.messages.get(messageId);
    const verifyTags = Array.isArray(verify.tags) ? verify.tags : [];
    console.log(`[OpenMailBot][Tag] Method B post-update tags: ${JSON.stringify(verifyTags)}`);

    if (verifyTags.includes(key)) {
      console.log(`[OpenMailBot][Tag] ✅ Method B: Tag "${key}" applied to msg ${messageId}`);
      return;
    } else {
      console.warn(`[OpenMailBot][Tag] ⚠️ Method B: tag not found after update`);
    }
  } catch (e) {
    console.warn(`[OpenMailBot][Tag] Method B (messenger.messages.update) failed: ${e.message}`);
  }

  // METHOD C: Use the tags.update API if available (TB 128+ alternative)
  try {
    if (browser.messages.tags && browser.messages.tags.update) {
      console.log(`[OpenMailBot][Tag] Method C: browser.messages.tags.update`);
      await browser.messages.tags.update(messageId, { tags: [key] });
      console.log(`[OpenMailBot][Tag] ✅ Method C succeeded`);
      return;
    }
  } catch (e) {
    console.warn(`[OpenMailBot][Tag] Method C failed: ${e.message}`);
  }

  // METHOD D: Try updating with object format { [key]: true }
  try {
    console.log(`[OpenMailBot][Tag] Method D: object-format tags`);
    await browser.messages.update(messageId, { tags: { [key]: true } });
    const verify = await browser.messages.get(messageId);
    console.log(`[OpenMailBot][Tag] Method D post-update tags: ${JSON.stringify(verify.tags)}`);
    console.log(`[OpenMailBot][Tag] ✅ Method D: attempted`);
  } catch (e) {
    console.warn(`[OpenMailBot][Tag] Method D failed: ${e.message}`);
  }

  console.error(`[OpenMailBot][Tag] ❌ ALL METHODS FAILED for tag "${key}" on msg ${messageId}`);
}

/**
 * Ensure the 1-minute repeating alarm exists.
 * Safe to call multiple times — checks before creating.
 */
function _ensureMonitorAlarm() {
  browser.alarms.get(MONITOR_ALARM_NAME).then(existing => {
    if (!existing) {
      browser.alarms.create(MONITOR_ALARM_NAME, {
        delayInMinutes : 1,
        periodInMinutes: MONITOR_INTERVAL_MINS
      });
      console.log("[OpenMailBot][Monitor] Alarm created (interval=" + MONITOR_INTERVAL_MINS + " min)");
    } else {
      console.log("[OpenMailBot][Monitor] Alarm already registered");
    }
  }).catch(() => {
    browser.alarms.create(MONITOR_ALARM_NAME, {
      delayInMinutes : 1,
      periodInMinutes: MONITOR_INTERVAL_MINS
    });
  });
}

// ─── MAIN MONITOR LOOP ───────────────────────────────────────────────────────

/**
 * Mirrors GAS monitorEmails():
 * - Scans inbox/sent folders for messages newer than the last check time
 * - Skips already-processed message IDs
 * - Applies domain filter
 * - Sends each new message to /api/label-email-async
 * - Polls for the label result and applies it as a Thunderbird tag
 */
async function monitorNewEmails() {
  const backendUrl = await getBackendUrl();
  if (!backendUrl) { console.log("[OpenMailBot][Monitor] No backend URL — skipping"); return; }

  const stored    = await browser.storage.local.get(MONITOR_LAST_CHECK_KEY);
  const lastCheck = stored[MONITOR_LAST_CHECK_KEY]
    ? new Date(stored[MONITOR_LAST_CHECK_KEY])
    : new Date(Date.now() - MONITOR_INTERVAL_MINS * 60 * 1000);
  const now = new Date();

  console.log(`[OpenMailBot][Monitor] === EMAIL MONITOR START ===`);
  console.log(`[OpenMailBot][Monitor] Last check : ${lastCheck.toISOString()}`);
  console.log(`[OpenMailBot][Monitor] Now        : ${now.toISOString()}`);

  const filters  = await _getMergedDomainFilters();
  let accounts = await browser.accounts.list();
  
  // FIX: Filter to ONLY configured accounts (those that completed onboarding)
  // This prevents labeling requests for accounts user never set up
  try {
    const r = await browser.storage.local.get("configured_accounts");
    const configured = r.configured_accounts || [];
    
    if (configured.length > 0) {
      const beforeFilter = accounts.length;
      const configuredAccounts = [];
      for (const acc of accounts) {
        try {
          const email = await getAccountEmail(acc.id);
          if (email && configured.includes(email)) {
            configuredAccounts.push(acc);
          } else if (email) {
            console.log(`[OpenMailBot][Monitor] ⊘ Skipping unconfigured account: ${email}`);
          }
        } catch (e) {
          console.warn(`[OpenMailBot][Monitor] Could not get email for account ${acc.id}: ${e.message}`);
        }
      }
      accounts = configuredAccounts;
      const afterFilter = accounts.length;
      console.log(`[OpenMailBot][Monitor] Account filtering: ${beforeFilter} total → ${afterFilter} configured (${beforeFilter - afterFilter} skipped)`);
    } else {
      console.log(`[OpenMailBot][Monitor] ℹ️ No configured accounts yet — monitor will skip all`);
      accounts = [];
    }
  } catch (e) {
    console.warn(`[OpenMailBot][Monitor] Could not filter by configured_accounts: ${e.message}`);
  }
  
  console.log(`[OpenMailBot][Monitor] Domain filters: ${filters.length} | Accounts: ${accounts.length}`);

  let found = 0, processed = 0, filtered = 0, skipped = 0, errors = 0;

  for (const acc of accounts) {
    const allFolders = _collectAllFolders(acc.folders);
    for (const folder of allFolders) {
      try {
        let page = await browser.messages.list(folder);
        while (page) {
          const candidates = (page.messages || []).filter(m => {
            const d = m.date ? new Date(m.date) : null;
            return d && d > lastCheck && d <= now;
          });
          found += candidates.length;

          for (const msg of candidates) {
            const outcome = await _processMonitorMessage(msg, filters).catch(e => {
              console.error(`[Monitor] ❌ Process error msg ${msg.id}: ${e.message}`);
              return "error";
            });
            if      (outcome === "processed") processed++;
            else if (outcome === "filtered")  filtered++;
            else if (outcome === "skipped")   skipped++;
            else                              errors++;
          }

          if (page.id) {
            try { page = await browser.messages.continueList(page.id); } catch(e) { break; }
          } else { break; }
        }
      } catch(e) {
        console.warn(`[OpenMailBot][Monitor] Folder error (${folder.name}): ${e.message}`);
      }
    }
  }

  await browser.storage.local.set({ [MONITOR_LAST_CHECK_KEY]: now.toISOString() });
  console.log(`[OpenMailBot][Monitor] === COMPLETE | found=${found} processed=${processed} filtered=${filtered} skipped=${skipped} errors=${errors} ===`);
}

/**
 * Process a single message in the background monitor.
 * Returns: "processed" | "filtered" | "skipped" | "error"
 */
async function _processMonitorMessage(msg, filters) {
  const msgId = String(msg.id);

  // Skip already-processed
  if (await _isMonitorMsgProcessed(msgId)) {
    console.log(`[Monitor] ⊘ Skipped (already processed): ${msgId} "${msg.subject}"`);
    return "skipped";
  }

  // Domain filter
  if (!filters) filters = await _getMergedDomainFilters();
  if (_shouldFilterEmail(msg.author, filters) ||
      (msg.recipients || []).some(r => _shouldFilterEmail(r, filters))) {
    console.log(`[Monitor] 🚫 Filtered: "${msg.subject}" from=${msg.author}`);
    await _markMonitorMsgProcessed(msgId);
    return "filtered";
  }

  try {
    const userId     = await getUserId();
    const backendUrl = await getBackendUrl();
    const full       = await browser.messages.getFull(msg.id);
    const threadId   = msg.headerMessageId || msgId;
    const msgData    = _fmtMsg(msg, full);

    console.log(`[Monitor] → Processing: "${msg.subject}" (from: ${msg.author})`);

    // Store attachments first so the pipeline can embed them
    const atts = await _getAttachments(msg.id);
    if (atts.length) {
      await _storeAtts(backendUrl, userId, threadId, msgId, atts)
        .catch(e => console.warn("[Monitor] storeAtts failed:", e.message));
    }

    // POST to /api/label-email-async  → server queues the labeling pipeline
    const resp = await fetch(`${backendUrl}/api/label-email-async`, {
      method : "POST",
      headers: { "Content-Type": "application/json" },
      body   : JSON.stringify({
        user_id    : userId,
        thread_id  : threadId,
        messages   : [msgData],
        attachments: atts
      })
    });

    if (resp.ok) {
      const data = await resp.json();
      console.log(`[Monitor] ✓ Queued: "${msg.subject}" | job_id=${data.job_id || "(sync)"}`);

      if (data.job_id) {
        // Async response — poll for label, then apply tag (non-blocking)
        _pollAndApplyMonitorLabel(msg.id, data.job_id, backendUrl).catch(e =>
          console.warn(`[Monitor] Label poll failed for msg ${msgId}: ${e.message}`)
        );
      } else {
        // Synchronous response — apply label immediately
        const label = data.label || data.category;
        if (label) {
          await _applyThunderbirdTag(msg.id, label);
          console.log(`[Monitor] ✅ Label "${label}" applied to "${msg.subject}"`);
        }
      }
    } else {
      const errText = await resp.text().catch(() => "");
      console.warn(`[Monitor] ⚠️ Server ${resp.status}: ${errText.substring(0, 200)}`);
    }

    await _markMonitorMsgProcessed(msgId);
    return "processed";
  } catch(e) {
    console.error(`[Monitor] ❌ Error for msg ${msgId}: ${e.message}`);
    return "error";
  }
}

// ─── MONITOR PERSISTENCE HELPERS ─────────────────────────────────────────────

async function _isMonitorMsgProcessed(msgId) {
  const r = await browser.storage.local.get(MONITOR_PROCESSED_KEY);
  return ((r[MONITOR_PROCESSED_KEY] || [])).includes(msgId);
}

async function _markMonitorMsgProcessed(msgId) {
  const r = await browser.storage.local.get(MONITOR_PROCESSED_KEY);
  let ids = r[MONITOR_PROCESSED_KEY] || [];
  if (ids.includes(msgId)) return;
  ids.push(msgId);
  // Ring buffer — evict oldest IDs to stay under cap
  if (ids.length > MONITOR_MAX_IDS) ids = ids.slice(-MONITOR_MAX_IDS);
  await browser.storage.local.set({ [MONITOR_PROCESSED_KEY]: ids });
}

// ─── LABEL POLL & APPLY (for async /api/label-email-async responses) ─────────

/**
 * Poll /api/job-status/:jobId until done, then apply the returned label as a Thunderbird tag.
 * Mirrors GAS _pollLabelingJob().
 */
async function _pollAndApplyMonitorLabel(messageId, jobId, backendUrl, maxMs = 120000) {
  if (!backendUrl) backendUrl = await getBackendUrl();
  let waited = 0;
  while (waited < maxMs) {
    await new Promise(r => setTimeout(r, 5000));
    waited += 5000;
    try {
      const resp = await fetch(`${backendUrl}/api/job-status/${jobId}`);
      if (resp.ok) {
        const d = await resp.json();
        if (d.status === "done") {
          const label = d.result && (d.result.label || d.result.category);
          if (label) {
            await _applyThunderbirdTag(messageId, label);
            console.log(`[Monitor] ✅ Poll → label="${label}" applied to msg ${messageId}`);
          } else {
            console.log(`[Monitor] ℹ️ Job ${jobId} done but no label returned`);
          }
          return;
        }
        if (d.status === "error") throw new Error("Job error: " + (d.error || "unknown"));
      }
    } catch(e) {
      if (e.message.startsWith("Job error:")) throw e;
      console.warn(`[Monitor][Poll] ${e.message}`);
    }
  }
  throw new Error(`Label poll timeout for job ${jobId} after ${maxMs / 1000}s`);
}

/**
 * Collect all leaf folders from a folder tree (recursively).
 */
function _collectAllFolders(folders) {
  if (!folders) return [];
  const priority = ["inbox", "sent"];
  const result   = [];
  function walk(flist) {
    for (const f of (flist || [])) {
      // Skip trash, junk and drafts to avoid re-indexing noise
      if (["trash","junk","drafts","templates","outbox"].includes((f.type||""))) continue;
      result.push(f);
      walk(f.subFolders);
    }
  }
  // Add priority folders first
  const sorted = [...(folders||[])].sort((a,b) => {
    const ai = priority.indexOf(a.type||"x");
    const bi = priority.indexOf(b.type||"x");
    return (ai===-1?99:ai) - (bi===-1?99:bi);
  });
  walk(sorted);
  return result;
}

// ─── INIT ────────────────────────────────────────────────────────────────────

browser.runtime.onInstalled.addListener(async () => {
  console.log("[OpenMailBot] installed / updated — loading addon_config.json");

  // Start background email monitor alarm
  _ensureMonitorAlarm();

  // Load config file (addon-side secrets/defaults)
  const cfg = await getAddonConfig();

  // Seed user_settings if not yet stored, or update backend_url / llm defaults on every reinstall/update
  const r = await browser.storage.local.get(["user_settings", "domain_filters"]);
  if (!r.user_settings) {
    // Fresh install — write full defaults from config
    const defaults = Object.assign({}, DEFAULT_SETTINGS);
    if (cfg.backend_url) defaults.backend_url = cfg.backend_url;
    if (cfg.llm_defaults && cfg.llm_defaults.model)            defaults.llm_model       = cfg.llm_defaults.model;
    if (cfg.llm_defaults && cfg.llm_defaults.embedding_model)  defaults.embedding_model = cfg.llm_defaults.embedding_model;
    await browser.storage.local.set({ user_settings: defaults });
    console.log("[OpenMailBot] user_settings seeded from addon_config.json");
  } else {
    // Reinstall / update — always apply backend_url and llm_defaults from addon_config.json
    // so changing the config file takes effect without the user having to reset settings
    const patch = {};
    if (cfg.backend_url) patch.backend_url = cfg.backend_url;
    if (cfg.llm_defaults && cfg.llm_defaults.model)           patch.llm_model       = cfg.llm_defaults.model;
    if (cfg.llm_defaults && cfg.llm_defaults.embedding_model) patch.embedding_model = cfg.llm_defaults.embedding_model;
    if (Object.keys(patch).length) {
      await browser.storage.local.set({ user_settings: Object.assign({}, r.user_settings, patch) });
      console.log("[OpenMailBot] user_settings updated from addon_config.json:", patch);
    }
  }

  // Seed domain_filters from config file if storage is empty
  if (!r.domain_filters || r.domain_filters.length === 0) {
    const cfgDoms  = (cfg.domain_filters && cfg.domain_filters.blocked_domains)  || [];
    const cfgAddrs = (cfg.domain_filters && cfg.domain_filters.blocked_addresses) || [];
    const combined = [...new Set([...cfgDoms, ...cfgAddrs].map(f => f.toLowerCase().trim()).filter(Boolean))];
    if (combined.length > 0) {
      await browser.storage.local.set({ domain_filters: combined });
      console.log("[OpenMailBot] domain_filters seeded from addon_config.json:", combined);
    }
  }

  // Seed process_months from config
  const mp = await browser.storage.local.get("process_last_n_months");
  if (!mp.process_last_n_months) {
    const defMonths = String((cfg.bulk_processing && cfg.bulk_processing.default_months) || 3);
    await browser.storage.local.set({ process_last_n_months: defMonths });
  }
});

// Re-register alarm on every Thunderbird startup (alarms don't persist across restarts in MV2)
browser.runtime.onStartup.addListener(() => {
  console.log("[OpenMailBot] startup — ensuring monitor alarm is registered");
  _ensureMonitorAlarm();
});

// ─── ALARM HANDLER (fires every MONITOR_INTERVAL_MINS) ───────────────────────
browser.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === MONITOR_ALARM_NAME) {
    monitorNewEmails().catch(e =>
      console.error("[OpenMailBot][Monitor] Unhandled error in monitorNewEmails:", e.message)
    );
  }
});

// ─── IMMEDIATE NEW-MAIL HOOK ─────────────────────────────────────────────────
// Fires as soon as Thunderbird receives a new message — no need to wait for the next alarm tick.
if (browser.messages && browser.messages.onNewMailReceived) {
  browser.messages.onNewMailReceived.addListener(async (folder, messages) => {
    console.log(`[OpenMailBot][Monitor] onNewMailReceived: ${messages.length} msg(s) in "${folder.name}"`);
    const filters = await _getMergedDomainFilters();
    for (const msg of messages) {
      await _processMonitorMessage(msg, filters).catch(e =>
        console.warn(`[OpenMailBot][Monitor] processMsg failed (${msg.id}): ${e.message}`)
      );
    }
  });
}

// ─── MESSAGE ROUTER ──────────────────────────────────────────────────────────

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background received action:", message.action);

  const handlers = {
    summarizeThread      : () => handleSummarizeThread(message.data),
    draftWithAttachments : () => handleDraftWithAttachments(message.data),
    createDraft          : () => handleCreateDraft(message.data),
    chatWithThread       : () => handleChatWithThread(message.data),
    loadSettings         : () => handleLoadSettings(),
    saveSettings         : () => handleSaveSettings(message.data),
    resetSettings        : () => handleResetSettings(),
    syncSettings         : () => handleSyncSettings(message.data),
    getDomainFilters     : () => handleGetDomainFilters(),
    saveDomainFilters    : () => handleSaveDomainFilters(message.data),
    testDomainFilters    : () => handleTestDomainFilters(message.data),
    runBulkProcess       : () => handleRunBulkProcess(message.data),
    getBulkJobStatus     : () => handleGetBulkJobStatus(),
    cancelBulkJob        : () => handleCancelBulkJob(),
    saveProcessMonths    : () => handleSaveProcessMonths(message.data),
    getProcessMonths     : () => handleGetProcessMonths()
  };

  const fn = handlers[message.action];
  if (!fn) { sendResponse({ error: "Unknown action: " + message.action }); return false; }
  fn().then(sendResponse).catch(e => sendResponse({ error: e.message }));
  return true;
});

// ─── THREAD HELPERS ──────────────────────────────────────────────────────────────────

/**
 * Get all messages in the same thread (subject-based, full thread).
 * Returns array of { meta, full } objects sorted oldest-first.
 */
async function getThreadMessages(messageId) {
  try {
    const msg    = await browser.messages.get(messageId);
    const folder = msg.folder;
    if (!folder) {
      return [{ meta: msg, full: await browser.messages.getFull(messageId) }];
    }
    let allMsgs = [];
    let page = await browser.messages.list(folder);
    while (page) {
      allMsgs = allMsgs.concat(page.messages || []);
      if (page.id) { page = await browser.messages.continueList(page.id); } else break;
    }
    const norm = s => (s||"").replace(/^(Re|Fwd?|AW|WG):\s*/gi,"").trim().toLowerCase();
    const base = norm(msg.subject);
    const thread = allMsgs
      .filter(m => m.id===messageId || norm(m.subject)===base)
      .sort((a,b) => new Date(a.date)-new Date(b.date))
      .slice(0,30);
    const results = await Promise.all(thread.map(async m => {
      try { return { meta: m, full: await browser.messages.getFull(m.id) }; }
      catch(e) { console.warn("getFull failed:",m.id,e.message); return null; }
    }));
    return results.filter(Boolean);
  } catch(e) {
    console.error("getThreadMessages:",e);
    const msg  = await browser.messages.get(messageId);
    const full = await browser.messages.getFull(messageId);
    return [{ meta: msg, full }];
  }
}

function buildThreadText(items) {
  return items.map(({meta,full}) =>
    `From: ${meta.author||"Unknown"}\nDate: ${meta.date?new Date(meta.date).toISOString():""}\nSubject: ${meta.subject||""}\n\n${extractPlainText(full)}`
  ).join("\n\n---\n\n");
}

/**
 * Extract plain text from message parts
 */
function extractPlainText(messagePart) {
  let text = "";
  
  if (messagePart.body) {
    text += messagePart.body;
  }
  
  if (messagePart.parts) {
    for (const part of messagePart.parts) {
      if (part.contentType === "text/plain") {
        text += part.body || "";
      } else if (part.parts) {
        text += extractPlainText(part);
      }
    }
  }
  
  return text;
}

// ─── FEATURE HANDLERS ─────────────────────────────────────────────────────────────

async function handleSummarizeThread({ messageId }) {
  const userId     = await getUserId();
  const backendUrl = await getBackendUrl();
  const items      = await getThreadMessages(messageId);
  const threadText = buildThreadText(items);
  const firstMeta  = items[0].meta;
  const threadId   = firstMeta.headerMessageId || String(firstMeta.id);

  // 1. Log all thread emails to server (so vector store is up-to-date)
  try { await _logEmailsToServer(backendUrl, userId, threadId, items.map(({meta,full})=>_fmtMsg(meta,full))); }
  catch(e) { console.warn("logEmail:", e.message); }

  // 2. Store attachments
  for (const {meta} of items) {
    try { const a=await _getAttachments(meta.id); if(a.length) await _storeAtts(backendUrl,userId,threadId,String(meta.id),a); }
    catch(e) { console.warn("storeAtts:",e.message); }
  }

  // 3. Try server-side RAG summarization (/api/summarize-thread uses indexed content)
  let summary;
  try {
    const resp = await fetch(`${backendUrl}/api/summarize-thread`, {
      method : "POST",
      headers: { "Content-Type": "application/json" },
      body   : JSON.stringify({ user_id: userId, thread_id: threadId })
    });
    if (resp.ok) {
      const data = await resp.json();
      const result = data.job_id ? await _pollJobStatus(data.job_id) : data;
      summary = result.summary || result.response || result.answer;
      if (summary) console.log("[Summarize] ✅ Used /api/summarize-thread (server-side RAG)");
    }
  } catch(e) {
    console.warn("[Summarize] /api/summarize-thread unavailable, falling back to /chat:", e.message);
  }

  // 4. Fallback: client-side prompt sent to /chat
  if (!summary) {
    summary = await callFlaskAPI(threadText, "summarize");
    console.log("[Summarize] Used /chat fallback");
  }

  return { success: true, summary, threadId, messageId };
}

async function handleCreateDraft({ messageId, summary }) {
  const prefs  = await getUserPreferences();
  const prompt = [
    "### Draft Response Email",
    `I am ${prefs.name} (${prefs.position}).`,
    `Write a ${prefs.tone} email response that:`,
    "- Acknowledges the current status",
    "- Restates pending actions",
    "- Requests the next expected step",
    "- Does NOT introduce new information",
    "",
    "Email format only. No explanations.",
    prefs.custom_instructions ? `\nAdditional instructions: ${prefs.custom_instructions}` : "",
    "",
    "Summary:", summary
  ].join("\n");
  const draftContent = await callFlaskAPI(prompt, "draft");
  const msg     = await browser.messages.get(messageId);
  const subject = msg.subject.match(/^Re:/i) ? msg.subject : `Re: ${msg.subject}`;
  await browser.compose.beginNew({ to:[msg.author], subject, plainTextBody:draftContent, isPlainText:true });
  return { success: true, draftContent };
}

async function handleDraftWithAttachments({ messageId }) {
  const userId     = await getUserId();
  const backendUrl = await getBackendUrl();
  const items      = await getThreadMessages(messageId);
  const firstMeta  = items[0].meta;
  const threadId   = firstMeta.headerMessageId || String(firstMeta.id);

  try { await _logEmailsToServer(backendUrl,userId,threadId,items.map(({meta,full})=>_fmtMsg(meta,full))); }
  catch(e) { console.warn("logEmail:",e.message); }

  let totalAtts = 0;
  for (const {meta} of items) {
    try {
      console.log(`[OpenMailBot][DraftAtts] Checking attachments for msg ${meta.id}`);
      const a = await _getAttachments(meta.id);
      console.log(`[OpenMailBot][DraftAtts] Found ${a.length} attachment(s) for msg ${meta.id}`);
      if (a.length) {
        console.log(`[OpenMailBot][DraftAtts] 📎 Storing attachments: ${a.map(att => att.filename).join(", ")}`);
        totalAtts += a.length;
        await _storeAtts(backendUrl, userId, threadId, String(meta.id), a);
        console.log(`[OpenMailBot][DraftAtts] ✓ Attachments stored successfully`);
      } else {
        console.log(`[OpenMailBot][DraftAtts] ℹ️ No attachments to store for msg ${meta.id}`);
      }
    }
    catch(e) { console.error("[OpenMailBot][DraftAtts] ❌ Error storing attachments:", e.message); }
  }

  const prefs  = await getUserPreferences();
  const result = await callPipelineAPI({ user_id:userId, thread_id:threadId, message_id:String(messageId), user_preferences:prefs });

  const draftContent   = result.draft_content || result.response || "No draft content received";
  const processingInfo = result.processing_info || {};
  const lastMeta       = items[items.length-1].meta;
  const subject        = lastMeta.subject.match(/^Re:/i) ? lastMeta.subject : `Re: ${lastMeta.subject}`;

  await browser.compose.beginNew({ to:[lastMeta.author], subject, plainTextBody:draftContent, isPlainText:true });
  return { success:true, draftContent, processingInfo, attachmentCount:totalAtts };
}

async function handleChatWithThread({ messageId, question }) {
  const userId     = await getUserId();
  const backendUrl = await getBackendUrl();
  const items      = await getThreadMessages(messageId);
  const firstMeta  = items[0].meta;
  const threadId   = firstMeta.headerMessageId || String(firstMeta.id);

  try { await _logEmailsToServer(backendUrl,userId,threadId,items.map(({meta,full})=>_fmtMsg(meta,full))); }
  catch(e) { console.warn("logEmail:",e.message); }
  for (const {meta} of items) {
    try { const a=await _getAttachments(meta.id); if(a.length) await _storeAtts(backendUrl,userId,threadId,String(meta.id),a); }
    catch(e) { console.warn("storeAtts:",e.message); }
  }

  const resp = await fetch(`${backendUrl}/api/chat-with-thread`, {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ user_id:userId, thread_id:threadId, question })
  });
  if (!resp.ok) { const t=await resp.text(); throw new Error(`Chat API (${resp.status}): ${t}`); }
  const initial = await resp.json();
  const result  = initial.job_id ? await _pollJobStatus(initial.job_id) : initial;
  if (!result.success) throw new Error(result.error||"Unknown server error");
  return { success:true, answer:result.answer, processingInfo:result.processing_info||{} };
}





// ─── SERVER COMMUNICATION ───────────────────────────────────────────────────────────

async function _logEmailsToServer(backendUrl, userId, threadId, messages) {
  const resp = await fetch(`${backendUrl}/api/log-email`, {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ user_id:userId, thread_id:threadId, messages })
  });
  if (!resp.ok) throw new Error(`log-email: server ${resp.status}: ${await resp.text()}`);
  return resp.text();
}

/**
 * Call /api/label-email — full processing pipeline:
 * preprocess → vector embed → label → graph store.
 * Used by bulk indexing instead of /api/log-email which only dumps JSON to disk.
 */
async function _labelEmailOnServer(backendUrl, userId, threadId, messages) {
  const fullUrl = `${backendUrl}/api/label-email`;
  const payload = { user_id:userId, thread_id:threadId, messages };
  const payloadStr = JSON.stringify(payload);
  
  console.log(`[OpenMailBot][API] 📤 REQUEST`);
  console.log(`[OpenMailBot][API] URL: ${fullUrl}`);
  console.log(`[OpenMailBot][API] Method: POST`);
  console.log(`[OpenMailBot][API] Content-Type: application/json`);
  console.log(`[OpenMailBot][API] Payload size: ${payloadStr.length} bytes`);
  console.log(`[OpenMailBot][API] Full payload: ${payloadStr}`);
  
  try {
    const resp = await fetch(fullUrl, {
      method:"POST", 
      headers:{"Content-Type":"application/json"},
      body: payloadStr
    });
    
    console.log(`[OpenMailBot][API] 📥 RESPONSE`);
    console.log(`[OpenMailBot][API] Status: ${resp.status} ${resp.statusText}`);
    console.log(`[OpenMailBot][API] OK: ${resp.ok}`);
    
    const respText = await resp.text();
    console.log(`[OpenMailBot][API] Body size: ${respText.length} bytes`);
    console.log(`[OpenMailBot][API] Body: ${respText}`);
    
    if (!resp.ok) {
      throw new Error(`label-email: server ${resp.status}: ${respText}`);
    }
    
    try {
      const json = JSON.parse(respText);
      console.log(`[OpenMailBot][API] ✅ Parsed JSON: ${JSON.stringify(json)}`);
      return json;
    } catch (parseErr) {
      console.log(`[OpenMailBot][API] Response is not JSON, returning raw text`);
      return respText;
    }
  } catch (err) {
    console.error(`[OpenMailBot][API] ❌ FETCH ERROR: ${err.message}`);
    throw err;
  }
}

async function _storeAtts(backendUrl, userId, threadId, messageId, attachments) {
  const fullUrl = `${backendUrl}/api/store-attachments`;
  const payload = { user_id:userId, thread_id:threadId, message_id:messageId, attachments };
  const payloadStr = JSON.stringify(payload);
  
  console.log(`[OpenMailBot][API] 📤 REQUEST (store-attachments)`);
  console.log(`[OpenMailBot][API] URL: ${fullUrl}`);
  console.log(`[OpenMailBot][API] Method: POST`);
  console.log(`[OpenMailBot][API] Attachments count: ${attachments.length}`);
  console.log(`[OpenMailBot][API] Payload size: ${payloadStr.length} bytes`);
  
  try {
    const resp = await fetch(fullUrl, {
      method:"POST", 
      headers:{"Content-Type":"application/json"},
      body: payloadStr
    });
    
    console.log(`[OpenMailBot][API] 📥 RESPONSE (store-attachments)`);
    console.log(`[OpenMailBot][API] Status: ${resp.status} ${resp.statusText}`);
    console.log(`[OpenMailBot][API] OK: ${resp.ok}`);
    
    const respText = await resp.text();
    console.log(`[OpenMailBot][API] Body: ${respText.substring(0, 500)}`);
    
    if (!resp.ok) {
      throw new Error(`store-attachments: server ${resp.status}: ${respText}`);
    }
    return respText;
  } catch (err) {
    console.error(`[OpenMailBot][API] ❌ FETCH ERROR (store-attachments): ${err.message}`);
    throw err;
  }
}

function _fmtMsg(meta, full) {
  return {
    message_id   : String(meta.id||""),
    from_address : meta.author||"",
    to           : meta.recipients||[],
    subject      : meta.subject||"",
    timestamp    : meta.date ? new Date(meta.date).toISOString() : new Date().toISOString(),
    body         : extractPlainText(full)
  };
}

async function _getAttachments(messageId) {
  try {
    console.log(`[OpenMailBot][GetAtts] Listing attachments for msg ${messageId}`);
    const atts = await browser.messages.listAttachments(messageId);
    console.log(`[OpenMailBot][GetAtts] Total attachments found: ${atts.length}`);
    
    if (atts.length === 0) {
      console.log(`[OpenMailBot][GetAtts] No attachments in msg ${messageId}`);
      return [];
    }
    
    const result = [];
    for (const att of atts) {
      const name = (att.name||"").toLowerCase();
      console.log(`[OpenMailBot][GetAtts] Checking attachment: ${att.name} (${name}), partName: ${att.partName}`);
      
      const isAllowed = ALLOWED_EXTENSIONS.some(ext => name.endsWith(ext));
      console.log(`[OpenMailBot][GetAtts] Extension check: isAllowed=${isAllowed}, allowed=[${ALLOWED_EXTENSIONS.join(",")}]`);
      
      if (!isAllowed) {
        console.log(`[OpenMailBot][GetAtts] ⏭️ Skipping ${att.name} — extension not in whitelist`);
        continue;
      }
      
      try {
        const file = await browser.messages.getAttachmentFile(messageId, att.partName);
        const buf  = await file.arrayBuffer();
        const encoded = _ab2b64(buf);
        console.log(`[OpenMailBot][GetAtts] ✅ Encoded ${att.name} (${buf.byteLength} bytes → ${encoded.length} b64 chars)`);
        result.push({ filename:att.name, content:encoded, mime_type:att.contentType||"application/octet-stream" });
      } catch(e) { 
        console.error(`[OpenMailBot][GetAtts] ❌ Error processing ${att.name}:`, e.message);
      }
    }
    console.log(`[OpenMailBot][GetAtts] Returning ${result.length} attachment(s)`);
    return result;
  } catch(e) { 
    console.error("[OpenMailBot][GetAtts] ❌ listAttachments failed:", e);
    return [];
  }
}

function _ab2b64(buffer) {
  let bin=""; const bytes=new Uint8Array(buffer);
  for (let i=0;i<bytes.byteLength;i++) bin+=String.fromCharCode(bytes[i]);
  return btoa(bin);
}

async function _pollJobStatus(jobId, maxMs=120000) {
  const backendUrl = await getBackendUrl();
  let waited = 0;
  while (waited < maxMs) {
    await new Promise(r=>setTimeout(r,3000)); waited+=3000;
    try {
      const resp = await fetch(`${backendUrl}/api/job-status/${jobId}`);
      if (resp.ok) {
        const d = await resp.json();
        if (d.status==="done")  return d.result;
        if (d.status==="error") throw new Error("Job error: "+d.error);
      }
    } catch(e) { console.warn("Poll:",e.message); }
  }
  throw new Error(`Timeout for job ${jobId}`);
}

// ─── USER HELPERS ─────────────────────────────────────────────────────────────
    
async function getUserId() {
  try {
    const accounts = await browser.accounts.list();
    if (accounts.length > 0) {
      const ids = accounts[0].identities || [];
      if (ids.length > 0) return ids[0].email;
    }
  } catch (e) { console.error("getUserId:", e); }
  return "unknown@user.com";
}

async function getUserPreferences() {
  const s = await _getSettings();
  return {
    name               : s.user_name     || "User",
    position           : s.user_position || "Professional",
    tone               : s.user_tone     || "professional",
    custom_instructions: s.system_prompt  || ""
  };
}

// ─── FLASK / PIPELINE APIs ─────────────────────────────────────────────────────────────

/**
 * Call Flask /chat endpoint
 */
async function callFlaskAPI(content, action) {
  const backendUrl = await getBackendUrl();
  const apiEndpoint = `${backendUrl}/chat`;
  const prompt = action === "summarize" ? SUMMARIZE_PROMPT + content : content;
  const response = await fetch(apiEndpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt })
  });
  if (!response.ok) throw new Error(`Flask API error: ${response.status}`);
  const data = await response.json();
  if (data.error) throw new Error(`Flask API error: ${data.error}`);
  if (data.response) return data.response;
  throw new Error("Unexpected API response format");
}

const SUMMARIZE_PROMPT =
`You are an expert enterprise communication analyst.
Analyze ALL emails and produce a chronological, structured summary.

### Instructions
1. Read every email.
2. Identify true chronological order.
3. Merge replies and forwards (no repetition).
4. Ignore greetings/signatures/disclaimers.
5. Focus on decisions, requests, approvals, blockers, commitments.

---

#### 1\uFE0F\u20E3 Conversation Overview
- **Topic:** <one-line summary>
- **Participants:** <key people and roles>
- **Time Range:** <first \u2192 last email date>

---

#### 2\uFE0F\u20E3 Chronological Timeline

**Step 1 \u2013 <Short Title>**
- What happened: <concise line>
- Outcome / Decision: <if any>
- Expectation / Ask: <what was requested next>

(Repeat for all major events)

---

#### 3\uFE0F\u20E3 Current Status
- **Current State:** <Awaiting approval / In progress / Blocked / Completed>
- **Owner:** <person responsible>
- **Pending Actions:** <bullet list>

---

#### 4\uFE0F\u20E3 Open Questions / Pending Requests
- <question> (<who responds>)

---

#### 5\uFE0F\u20E3 Final Ask / Next Expected Action
- **Action Required:** <clear action>
- **From Whom:** <person/team>
- **Deadline:** <date or "Not specified">

### Rules: Factual, neutral, no invented info, professional, concise.

Email Thread:
`;

async function callPipelineAPI(requestData) {
  const backendUrl = await getBackendUrl();
  const resp = await fetch(`${backendUrl}/api/draft-with-attachments`, {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify(requestData)
  });
  if (!resp.ok) { const t=await resp.text(); throw new Error(`Pipeline API (${resp.status}): ${t}`); }
  const ct = resp.headers.get("content-type")||""; 
  if (ct.includes("text/html")) throw new Error("Server returned HTML. Is the backend running?");
  const data = await resp.json();
  if (data.error) throw new Error("Pipeline: "+data.error);
  if (data.job_id) return _pollJobStatus(data.job_id);
  return data;
}
  



